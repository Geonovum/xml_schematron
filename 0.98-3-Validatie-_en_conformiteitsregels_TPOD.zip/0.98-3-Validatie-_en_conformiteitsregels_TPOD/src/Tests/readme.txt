Deze twee scripts dienen om alle test-directories te doorlopen.

Ze werken alleen op unix-achtige shells:

https://www.howtogeek.com/249966/how-to-install-and-use-the-linux-bash-shell-on-windows-10/