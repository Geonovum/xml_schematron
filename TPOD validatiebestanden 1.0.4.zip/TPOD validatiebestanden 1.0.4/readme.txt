Wijzigingen TPOD validatiebestanden 1.0.4
- Structuur voor genereren businessrules gereed

