Wijzigingen TPOD validatiebestanden 1.0.3
- Uitvoer foutmeldingen nu in JSON, nu in vaste structuur, en voorbereid op business-rules
