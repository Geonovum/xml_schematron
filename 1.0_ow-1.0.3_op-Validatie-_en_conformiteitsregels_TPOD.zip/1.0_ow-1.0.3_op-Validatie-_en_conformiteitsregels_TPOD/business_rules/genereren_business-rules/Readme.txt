Plaats het gewenste validaties.sch (van later datum dan 18/9/2020 + abstract_pattern_error.sch en abstract_pattern_warning.sch) in deze directory en run het xslt-script 

