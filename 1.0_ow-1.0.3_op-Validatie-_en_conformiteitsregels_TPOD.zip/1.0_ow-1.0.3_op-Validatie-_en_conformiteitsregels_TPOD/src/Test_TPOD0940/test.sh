#!/usr/bin/sh

../Tests/test_data.sh 0940 GML