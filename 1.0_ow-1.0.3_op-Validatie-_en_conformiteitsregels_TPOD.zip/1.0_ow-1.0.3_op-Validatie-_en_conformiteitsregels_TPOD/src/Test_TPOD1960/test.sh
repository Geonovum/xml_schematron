#!/usr/bin/sh

../Tests/test_data.sh 1960 OW