#!/usr/bin/sh

../Tests/test_data.sh 0750 OP-OmgevingVerordening