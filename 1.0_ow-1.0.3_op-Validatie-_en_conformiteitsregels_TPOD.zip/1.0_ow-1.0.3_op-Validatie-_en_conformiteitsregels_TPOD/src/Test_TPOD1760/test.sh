#!/usr/bin/sh

../Tests/test_data.sh 1760 OW