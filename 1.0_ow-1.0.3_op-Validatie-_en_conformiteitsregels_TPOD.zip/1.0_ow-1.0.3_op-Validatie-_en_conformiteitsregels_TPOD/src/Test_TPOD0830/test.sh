#!/usr/bin/sh

../Tests/test_data.sh 0830 OP-Omgevingsplan