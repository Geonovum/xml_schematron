#!/usr/bin/sh

../Tests/test_data.sh 1070 OP-OmgevingVerordening