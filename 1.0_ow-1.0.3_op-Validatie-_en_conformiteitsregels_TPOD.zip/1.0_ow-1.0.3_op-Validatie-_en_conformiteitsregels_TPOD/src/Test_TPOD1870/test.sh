#!/usr/bin/sh

../Tests/test_data.sh 1870 OW