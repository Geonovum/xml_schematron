#!/usr/bin/sh

../Tests/test_data.sh 2000 OW