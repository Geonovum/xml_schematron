#!/usr/bin/sh

../Tests/test_data.sh 0620 OP-OmgevingVerordening