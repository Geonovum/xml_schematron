#!/usr/bin/sh

../Tests/test_data.sh 1970 OW