Deze validatie-set valideert op OW-versie: 1.0 en OP-versie: 0.98.1
Instructie hoe de validatie-set te gebruiken staat in de directory Validaties
